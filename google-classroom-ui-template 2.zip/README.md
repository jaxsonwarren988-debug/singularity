# SINGULARITY OS

A complete browser-native desktop environment: agent AI, proxy browser, arcade, 18 GPU shaders and a mesh network between your tabs. Everything is local — no server, no accounts leaving your machine.

---

## Publishing it (fixing a white screen)

The Static.app-ready ZIP is **`singularity-staticapp.zip`** in the project root. It contains `index.html` and `200.html` at the archive root, exactly where Static.app expects them. It is built from production output; it does **not** point at `/src/main.tsx`.

1. Download `singularity-staticapp.zip` from the project files and upload that ZIP to Static.app. Or rebuild it yourself:
   ```bash
   npm install
   npm run build
   mkdir -p static-deploy
   cp dist/index.html static-deploy/index.html
   cp dist/index.html static-deploy/200.html
   cd static-deploy && zip -q ../singularity-staticapp.zip index.html 200.html
   ```
2. In Static.app choose its React/static website upload and upload the ZIP.
3. The ZIP has `index.html` directly at its root (not nested in a folder).
4. Open the published `https://…staticdomains.app` URL.

### If you still see a blank page

The app now ships with a boot watchdog: after six seconds it replaces the loading screen with a diagnostic panel showing the actual error. Read that panel first. The usual causes are:

| Symptom | Cause | Fix |
|---|---|---|
| Panel says `Failed to load script: https://…/src/main.tsx` | The source `index.html` was uploaded, not the build | Upload `singularity-staticapp.zip` from the project root. It contains the compiled inline bundle. |
| Blank white page, no panel | The file wasn't served as HTML | Your host must return `Content-Type: text/html`. Static hosts sometimes serve unknown uploads as `text/plain`. |
| Panel says "Failed to load script" | The upload was truncated | Re-upload `singularity-staticapp.zip`; hard-reload with `Ctrl/Cmd + Shift + R`. |
| Panel shows a JS exception | Corrupted saved profile | Click **Reset local data** on the panel. |
| Works locally, blank when hosted | Opened via `file://` | Some browsers block module scripts on `file://`. Use a real host or `npx serve dist`. |

On static.app specifically: drop `index.html` at the top level of the upload area (not a folder), then open the site URL rather than the file preview.

### Local preview
```bash
npx serve dist
```

---

## Using KALMIA (the agent AI)

Open **KALMIA & NOVA AI** from the dock. Press the book icon any time to reopen the instructions.

**Three modes**

- **Agent** — describe a task. KALMIA writes a plan, you approve it, then a visible cursor moves across the desktop and clicks the real buttons while each step reports what it did.
- **Chat** — ask questions, get writing, get step-by-step maths.
- **Battle** — KALMIA is always one contestant; compare it with NOVA-Kernel, KALMIA-Code or your configured cloud endpoint. Responses run in parallel and show their source and elapsed time; there is no fake automatic winner.

**Screen vision**

- **Link screen** uses your browser's screen picker so KALMIA can see any window or tab you choose. Frames are attached to your messages.
- Without linking, **workspace vision** still reads your open windows, the page loaded in Portal, your active note and your task list.
- The camera icon takes a one-off snapshot and asks for analysis.

**Things to try**

```
set up study mode for my biology homework
write an essay about black holes
make flashcards for photosynthesis
solve 2x^2 - 7x + 3 = 0
search youtube for lofi beats
build me a pong game
make it look like a hacker terminal
click the reactor 500 times
```

KALMIA drives *this* desktop. It cannot move your real operating system's mouse — no web page can. Everything it does is shown on screen and logged in the plan.

**Models** — works offline with the built-in engine. Cloud mode adds a free keyless endpoint, or point it at OpenAI, Groq, OpenRouter or a local Ollama server with your own key.

---

## Portal (the browser)

| Engine | What it does |
|---|---|
| **Proxy** | Fetches through four CORS relays, rewrites the HTML, and intercepts link clicks so navigation stays inside the proxy. |
| **Reader** | Clean article text via Jina Reader / the Wikipedia API. Fastest option. |
| **Direct** | Plain iframe. Also converts GitHub file links to the jsDelivr CDN so real game files run. |
| **YouTube** | Native search through Piped/Invidious mirrors plus a privacy-enhanced embed player. |
| **TikTok** | Individual public videos use TikTok's official Player v1 iframe. Private, region-limited or embed-disabled posts get an open-original fallback; the full feed is not embeddable. |

TikTok video playback uses the [official Player v1 iframe](https://developers.tiktok.com/docs/en/embed-player). TikTok can still reject individual posts based on privacy, region or its own embed settings.

Search anything and Portal runs a **native multi-source search** (Wikipedia, DuckDuckGo, Hacker News, GitHub) that never hits an X-Frame block.

The **Directory** button holds 40+ curated destinations and eight full server-side proxy engines for sites that refuse framing.

---

## What else is inside

- **12 native games** — Slope 3D, Geometry Dash, Void Survivors, Cyber Doom 3D, Tetris Effect, Jetpack Overdrive, Cyber Slash, 2048, Neon Drift, Stack Tower, Minesweeper Neo, Word Cipher. Plus a Custom Studio for uploading your own `.html` games or having KALMIA build one.
- **16 ambience layers** — drones, ocean, thunder, campfire, café murmur, vinyl, singing bowls, brown/pink noise, binaural and gamma beats, with eleven presets and a sleep timer.
- **16 themes · 18 shaders** — including four light themes.
- **Overwatch** — admin console with live screens from other tabs and real remote control.
- **Terminal** — 27 commands covering the whole OS.

### Shortcuts
`⌘/Ctrl+K` command deck · `Shift+S` panic · `Shift+L` lock · `Shift+T` terminal · `Shift+M` modules · `Shift+A` KALMIA · `Shift+W` close window

Root account: **admin / Kioto** — change it in Overwatch → Accounts.
